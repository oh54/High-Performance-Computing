Program should be executed with 
./ass2_main <method> <N> <threshold> <kmax>

where method should be either:
jacobi	- sequential jacobi
gauss	- Gauss-Seidel
omp	- initial parallelization
omp2	- second parallelization
omp3 	- first touch added to omp2
